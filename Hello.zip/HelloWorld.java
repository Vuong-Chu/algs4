/**
 * This code is to print out a string to the screen
 * @author vuongchu
 *
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
